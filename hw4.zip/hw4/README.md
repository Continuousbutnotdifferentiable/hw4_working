### CS389 HW4: Lets network.

#### David Herrero-Quevedo & Michael Kalange

We used modified versions of Marika and Jill's cache
need to ensure evictor implementation works with my_size_cache_
write test to update value

compile using:: g++ <filename> -l boost_system -pthread
run file
check port 

check pointer returned by get different than passed to set

MEMCOPY for dealing with deep copy in set